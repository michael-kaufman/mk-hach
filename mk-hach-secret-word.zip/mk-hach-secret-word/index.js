// Run immediately inside an async function so file reads and imports can use await.
// The function also keeps variables local when pasted into the browser console.
(async () => {
  // Detect whether a browser document is available before using browser-only APIs.
  const isBrowser = typeof window !== 'undefined' && typeof document !== 'undefined';
  let sourceDocument;

  // In the browser, read the table from the currently open challenge page.
  if (isBrowser) {
    sourceDocument = document;
  } else {
    // In Node.js, load the file and create a DOM so both environments can use
    // the same querySelector, rows, and cells APIs below.
    const { readFile } = await import('node:fs/promises');
    const { dirname, resolve } = await import('node:path');
    const { JSDOM } = await import('jsdom');
    // Resolve the HTML path relative to this script, not the terminal's folder.
    // UTF-8 preserves the block characters stored in the file.
    const html = await readFile(
      resolve(dirname(process.argv[1]), 'Coordinate Decoder Challenge.html'),
      'utf8',);
    // JSDOM parses the HTML into a document; it does not render the page.
    sourceDocument = new JSDOM(html).window.document;
  }

  // Select only the pixel table's body, excluding the column headers.
  const tbody = sourceDocument.querySelector('#pixels tbody');

  // Stop with a useful error if the expected table is missing.
  if (!tbody) {
    throw new Error('Could not find a table body in the HTML file.');
  }

  // rows contains table row elements, so blank lines in the HTML are ignored.
  // Store valid points in order and track the latest entry for each coordinate.
  const rows = tbody.rows;
  const grid = [];
  const seenCoordinates = new Map();

  // Validate each row before letting its values affect the canvas.
  for (let i = 0; i < rows.length; i++) {
    const cells = rows[i].cells;
    // Every point needs exactly three cells: x, y, and a utf8 symbol.
    if (cells.length !== 3) {
      console.warn(`Skipping row ${i + 1}: expected two integers and a symbol.`);
      continue;
    }

    // Remove surrounding whitespace and convert coordinate text into numbers.
    const [xText, yText, char] = Array.from(cells, cell => cell.textContent.trim());
    const x = Number(xText);
    const y = Number(yText);
    // Require decimal digits and safe integers: blanks, fractions, negatives, and nums.
    const validCoordinates = [xText, yText].every(value => /^\d+$/.test(value))
      && Number.isSafeInteger(x) && Number.isSafeInteger(y);

    // Array.from counts Unicode code points instead of UTF-16 code units.
    // This accepts a single supplementary character too, but not multi-code-point symbols.
    if (!validCoordinates || Array.from(char).length !== 1) {
      console.warn(`Skipping row ${i + 1}: expected two nonnegative integers and one Unicode symbol.`);
      continue;
    }

    // Compare repeated coordinates with their previous entry. Identical symbols
    // are harmless; different symbols produce a warning with table row numbers.
    const key = `${x},${y}`;
    const previous = seenCoordinates.get(key);
    //I thought there were conflicting symbols but not really
    if (previous && previous.char !== char) {
      console.warn(
        `Conflicting symbols at (${x}, ${y}): tbody row ${previous.row} has "${previous.char}", `
        + `but tbody row ${i + 1} has "${char}". Using "${char}" (last entry).`,
      );
    }
    // Remember this entry for future comparisons and preserve source order.
    seenCoordinates.set(key, { char, row: i + 1 });
    grid.push({ x, y, char });
  }

  // Coordinates start at zero, so the largest coordinate plus one is the size.
  // The -1 fallback makes an empty input produce a zero-sized canvas.
  const width = Math.max(-1, ...grid.map(point => point.x)) + 1;
  const height = Math.max(-1, ...grid.map(point => point.y)) + 1;
  // Create a separate array for each row and leave unspecified positions blank.
  const canvas = Array.from({ length: height }, () => Array(width).fill(' '));

  // Arrays are indexed by row then column: y first, x second, with y=0 at the top.
  // Processing in source order means the last entry wins for duplicate coordinates.
  for (const { x, y, char } of grid) {
    canvas[y][x] = char;
  }

  // Join cells without separators and rows with newlines to preserve the layout.
  const output = canvas.map(row => row.join('')).join('\n');
  // Browser consoles support %c text styling; %s inserts the grid as text.
  // Node.js prints the same grid as plain text because terminal output has no CSS.
  if (isBrowser) {
    console.log('%c%s', 'font-family: monospace; font-size: 20px; line-height: 1;', output);
  } else {
    console.log(output);
  }
// Report loading or parsing failures and signal failure to the shell in Node.js.
})().catch(error => {
  console.error(error);
  if (typeof process !== 'undefined') process.exitCode = 1;
});
